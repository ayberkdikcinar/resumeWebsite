@include('front.layouts.header')
@yield('content')
@include('front.layouts.footer')