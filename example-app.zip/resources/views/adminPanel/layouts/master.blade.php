@include('adminPanel.layouts.header')
@include('adminPanel.layouts.menu')
@yield('content')
@include('adminPanel.layouts.footer')