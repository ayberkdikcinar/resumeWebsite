
<?php $__env->startSection('title',''); ?>
<?php $__env->startSection('content'); ?>
<?php $__env->startSection('css'); ?>
  <link href="<?php echo e(asset('back/')); ?>/css/view-detailed-user.css" rel="stylesheet">  
<?php $__env->stopSection(); ?>
<div class="container emp-profile">
            
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-img">
                            <img src="<?php echo e(asset('')); ?><?php echo e($user->photo_url); ?>" alt=""/>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="profile-head">
                                    <h5>
                                        <?php echo e($user->name); ?> <?php echo e($user->surname); ?>

                                    </h5>
                                    <h6>
                                        <strong>Current position:</strong> <?php echo e($user->current_position); ?>

                                    </h6>

                            <ul class="nav nav-tabs" id="myTab" role="tablist">
                                <li class="nav-item">
                                    <a class="nav-link active" id="home-tab" data-toggle="tab" href="#home" role="tab" aria-controls="home" aria-selected="true">About</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="experience-tab" data-toggle="tab" href="#experience" role="tab" aria-controls="experience" aria-selected="false">Experience</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="education-tab" data-toggle="tab" href="#education" role="tab" aria-controls="education" aria-selected="false">Education</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="courses-tab" data-toggle="tab" href="#courses" role="tab" aria-controls="courses" aria-selected="false">Courses</a>
                                </li>
                                <li class="nav-item">
                                    <a class="nav-link" id="documents-tab" data-toggle="tab" href="#documents" role="tab" aria-controls="documents" aria-selected="false">Documents</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                    <div class="col-md-2">
                        <a href="<?php echo e(route('admin.user.generatePDF',$user->id)); ?>" class="profile-edit-btn">Download as a PDF</a>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-4">
                        <div class="profile-work">
                            <br/>
                            <p><strong>Contact Information</strong></p>
                            Email: <?php echo e($user->email); ?><br/>
                            Phone: <?php echo e($user->phone); ?>

                            <hr>
                            <p><strong>Hard Skills</strong></p>
                            <ul style="list-style-type:none; padding: 0;">
                                <?php $__currentLoopData = $user->skills->where('type','hard'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <hr>
                            <p><strong>Soft Skills</strong></p>
                            <ul style="list-style-type:none; padding: 0;">
                                <?php $__currentLoopData = $user->skills->where('type','soft'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <hr>
                            <p><strong>Expert Skills</strong></p>
                            <ul style="list-style-type:none; padding: 0;">
                                <?php $__currentLoopData = $user->skills->where('type','expert'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li><?php echo e($item->name); ?></li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <hr>
                            <p><strong>Languages</strong></p>
                            <ul style="list-style-type:none; padding: 0;">
                                <?php $__currentLoopData = $user->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <?php if($item->proficiency=='intermediate'): ?>
                                            <li style="color:green;"><?php echo e($item->proficiency); ?></li> 
                                            <?php elseif($item->proficiency=='advanced'): ?>
                                            <li style="color:red;"><?php echo e($item->proficiency); ?></li> 
                                            <?php else: ?>
                                            <li style="color:orange;"><?php echo e($item->proficiency); ?></li> 
                                            <?php endif; ?> 
                                        </div>
                                        <div class="col-md-6">       
                                            <li> <?php echo e($item->name); ?></li>
                                            </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                            <hr>
                        </div>
                    </div>
                    <div class="col-md-6" style="margin-top: -16%;">
                        <div class="tab-content profile-tab" id="myTabContent">
                            <div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Firstname</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><?php echo e($user->name); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Lastname</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><?php echo e($user->surname); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Age</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><?php echo e($user->getAge()); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Country of birth</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><?php echo e($user->country_of_birth); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Country of Residence</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><?php echo e($user->country_of_residence); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-4">
                                                <label>Marital status</label>
                                            </div>
                                            <div class="col-md-8">
                                                <p><?php echo e($user->marital_status); ?></p>
                                            </div>
                                        </div>
                                        <div class="row">
                                            <div class="col-md-10">
                                                <label>Description</label>
                                                <p><?php echo e($user->about); ?></p>
                                            </div>
                                        </div>
                                        <label>Job Preferences</label>     
                                        <ul style="list-style-type:none; padding: 0;">
                                        <?php $__currentLoopData = $user->jobPreferences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <li>Field <p><?php echo e($item->field); ?></p></li> 
                                            </div>
                                            <div class="col-md-6">
                                                <li>Desired Location <p><?php echo e($item->desired_location); ?></p></li>   
                                            </div>
                                        </div>   
                                        <hr>  
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                                        
                                        </ul>                  
                            </div>
                            <div class="tab-pane fade" id="experience" role="tabpanel" aria-labelledby="experience-tab">
                                        <?php $__currentLoopData = $user->experiences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                        <div class="row">  
                                            <div class="col-md-12">
                                                <div class="card" style="width: 32rem; margin-bottom:5%;">
                                                    <div class="card-body">
                                                      <h5 class="card-title"><strong><?php echo e($item->company_name); ?></strong></h5>
                                                      <h6>Description</h6>
                                                      <p class="card-text"><?php echo e($item->description); ?></p>
                                                    </div>
                                                    <ul class="list-group list-group-flush">
                                                      <li class="list-group-item"><h6>Position Title - Position</h6><p><?php echo e($item->position_title); ?> - <?php echo e($item->position); ?></p></li>
                                                      <li class="list-group-item"><h6>From - To</h6><p><?php echo e($item->from_time); ?> - <?php echo e($item->to_time); ?></p></li>
                                                      <li class="list-group-item"><h6>Location</h6><p><?php echo e($item->location); ?></p></li>
                                                    </ul>
                                                  </div>
                                            </div>      
                                        </div>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <div class="tab-pane fade" id="education" role="tabpanel" aria-labelledby="education-tab">
                                
                                <?php $__currentLoopData = $user->educations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <div class="row">  
                                    <div class="col-md-12">
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                              <h5 class="card-title"><strong><?php echo e($item->school); ?></strong></h5>
                                              <h6>Description</h6>
                                              <p class="card-text"><?php echo e($item->description); ?></p>
                                            </div>
                                            <ul class="list-group list-group-flush">
                                              <li class="list-group-item"><h6>Education Level - Degree</h6><p><?php echo e($item->education_level); ?> - <?php echo e($item->degree); ?></p></li>
                                              <li class="list-group-item"><h6>From - To</h6><p><?php echo e($item->from_time); ?> - <?php echo e($item->to_time); ?></p></li>
                                              <li class="list-group-item"><h6>Area of study</h6><p><?php echo e($item->area_of_study); ?></p></li>
                                              <li class="list-group-item"><h6>Location</h6><p><?php echo e($item->location); ?></p></li>
                                              <li class="list-group-item"><h6>Activities and societies</h6><p><?php echo e($item->activities_societies); ?></p></li>
                                            </ul>
                                          </div>
                                    </div>      
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="tab-pane fade" id="courses" role="tabpanel" aria-labelledby="courses-tab">
                                
                                <?php $__currentLoopData = $user->courses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                <div class="row">  
                                    <div class="col-md-12">
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                              <h5 class="card-title"><strong><?php echo e($item->name); ?></strong></h5>
                                              <h6>Description</h6>
                                              <p class="card-text"><?php echo e($item->description); ?></p>
                                            </div>
                                            <ul class="list-group list-group-flush">
                                              <li class="list-group-item"><h6>Provider</h6><p><?php echo e($item->provider); ?></p></li>
                                              <li class="list-group-item"><h6>Completed date</h6><p><?php echo e($item->completed_time); ?></p></li>
                                            </ul>
                                          </div>
                                    </div>      
                                </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </div>
                            <div class="tab-pane fade" id="documents" role="tabpanel" aria-labelledby="documents-tab">
                            
                                <div class="row">  
                                    <div class="col-md-12">
                                        <p>1. English Tests (IELTS,TOEFL,etc.)</p>
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                                <?php $__currentLoopData = $user->documents->where('type','english-test'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                              <h5 class="card-title">Document</h5>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                          </div>
                                    </div>      
                                </div>
                                <div class="row">  
                                    <div class="col-md-12">
                                        <p>2. Last degree earned (BA,MBA,PHD,Associate)</p>
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                                <?php $__currentLoopData = $user->documents->where('type','last-degree-earned'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                              <h5 class="card-title">Document</h5>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                          </div>
                                    </div>      
                                </div>
                                <div class="row">  
                                    <div class="col-md-12">
                                        <p>3. Professional courses(Design, Marketing, Finance, Carpenter, etc)</p>
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                                <?php $__currentLoopData = $user->documents->where('type','professional-course'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                              <h5 class="card-title">Document</h5>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                          </div>
                                    </div>      
                                </div>
                                <div class="row">  
                                    <div class="col-md-12">
                                        <p>4. Identification document (Passport or driver’s license, or any other document)</p>
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                                <?php $__currentLoopData = $user->documents->where('type','identification-document'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>    
                                              <h5 class="card-title">Document</h5>
                                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                          </div>
                                    </div>      
                                </div>
                                <div class="row">  
                                    <div class="col-md-12">
                                        <p>5. Additional Certificates</p>
                                        <div class="card" style="width: 32rem; margin-bottom:5%;">
                                            <div class="card-body">
                                                <?php $__currentLoopData = $user->documents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
                                                <a href="<?php echo e(url('/',$item->document_url)); ?>" target="_blank"><h5 class="card-title">Document</h5></a>   
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </div>
                                          </div>
                                    </div>      
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
                      
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/users/userdetails.blade.php ENDPATH**/ ?>