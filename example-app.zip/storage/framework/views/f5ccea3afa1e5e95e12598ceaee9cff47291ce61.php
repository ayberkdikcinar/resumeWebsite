
<?php $__env->startSection('title','Update User'); ?>
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Updating user: <?php echo e($user->username); ?></h6>
    </div>
    <div class="card-body">
        <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>    
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.user.update',$user->id)); ?>" method="POST">
            <?php echo method_field('PUT'); ?>
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Username <label style="color: red" title="must containt at least 3, at most 15 character">*</label> </label>
                <input type="text" name="username" class="form-control" value="<?php echo e($user->username); ?>" required>
            </div>
            <div class="form-group">
                <label>Name <label style="color: red" title="must contain at least 3 characters">*</label></label>
                <input type="text" name="name" class="form-control" value="<?php echo e($user->name); ?>" required>
            </div>
            <div class="form-group">
                <label>Surname <label style="color: red" title="must contain at least 3 characters">*</label></label>
                <input type="text" name="surname" class="form-control" value="<?php echo e($user->surname); ?>" required>
            </div>
            <div class="form-group">
                <label>Phone </label>
                <input type="text" name="phone" class="form-control"value="<?php echo e($user->phone); ?>">
            </div>
            <div class="form-group">
                <label>Email <label style="color: red" title="Example: example@example.com">*</label></label>
                <input type="text" name="email" class="form-control" value="<?php echo e($user->email); ?>" required>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn-block btn btn-primary">Update</button>
            </div>

        </form>


    
    
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/users/editUser.blade.php ENDPATH**/ ?>