
<?php $__env->startSection('content'); ?>
    <div class="container m-1">
        <a href="<?php echo e(route('admin.user.index')); ?>" class="btn btn-sm btn-warning" style="display: inline-block;"><i class="fas fa-arrow-circle-left" style="color: darkblue; font-size: 18px"> Go back to user list</i></a>
        <h1 class="lead mt-3">Send mail to <?php echo e($user->username); ?></h1>
        <div class="row">
            <div class="col md-12">
                <div class="card">
                    <div class="class-body">
                        <?php if(\Session::has('success')): ?>
                            <div class="alert alert-success m-3"><?php echo e(\Session::get('success')); ?></div>
                            <?php echo e(\Session::forget('success')); ?>

                        <?php endif; ?>
                        <?php if(\Session::has('error')): ?>
                            <div class="alert alert-danger m-3"><?php echo e(\Session::get('error')); ?></div>
                            <?php echo e(\Session::forget('error')); ?>

                        <?php endif; ?>
                        <form method="post" action="<?php echo e(route('admin.mailSend',$user->id)); ?>" enctype="multipart/form-data" class="m-5">
                            <?php echo csrf_field(); ?>
                            <div class="mb-3">
                                <label for="email" class="form-label">Email Address</label>
                                <input type="email" class="form-control" id="email" placeholder="name@example.com" name="email" value="<?php echo e($user->email); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="attachment" class="form-label">Mail Body</label>
                                <textarea class="form-control" name="email_body" id="" cols="30" rows="6"></textarea>
                            </div>
                            <div class="mb-3">
                                <label for="attachment" class="form-label">Attachment</label>
                                <input class="form-control" type="file" id="attachment" name="attachment">
                            </div>                           
                            <input type="submit" name="Send mail" class="form-control btn btn-primary" value="Send">  
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/mail/mailView.blade.php ENDPATH**/ ?>