
<?php $__env->startSection('title'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
  
    <div class="card-body">
        <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>    
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.siteSettingsPost')); ?>" method="POST" enctype="multipart/form-data">     
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Title <label style="color: red">*</label> </label>
                <input type="text" name="title" class="form-control" value="<?php echo e($setting->title); ?>" required>
            </div>
            <div class="form-group">
                <label>Logo <label style="color: red">*</label></label><br>
                <img src="<?php echo e(asset('')); ?><?php echo e($setting->logo_url); ?>" style="margin: 2%" width="150" id="uploadPreview">
                <input id="uploadImage" type="file" name="logo" class="form-control" accept="image/*" onchange="PreviewImage();">
            </div>
            <div class="form-group">
                <label>Social Links</label><br>        
              
                <div class="row">
                    <div class="col md-6"><i class="fab fa-facebook"></i><input type="text" name="facebook" class="form-control" value="<?php echo e($setting->facebook_url); ?>"></div>
                    <div class="col md-6"><i class="fab fa-linkedin"></i><input type="text" name="linkedin" class="form-control" value="<?php echo e($setting->linkedin_url); ?>"></div>
                </div>
                <div class="row">
                    <div class="col md-6"><i class="fab fa-instagram"></i><input type="text" name="instagram" class="form-control" value="<?php echo e($setting->instagram_url); ?>"></div>
                    <div class="col md-6"><i class="fab fa-twitter"></i><input type="text" name="twitter" class="form-control" value="<?php echo e($setting->twitter_url); ?>"></div>
                </div>
                
            </div>
            <div class="form-group">
                <label>License</label>
                <textarea type="text" name="license" class="form-control" rows="3"><?php echo e($setting->license); ?></textarea>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn-block btn btn-primary">Update</button>
            </div>

        </form>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/pages/site_settings_update.blade.php ENDPATH**/ ?>