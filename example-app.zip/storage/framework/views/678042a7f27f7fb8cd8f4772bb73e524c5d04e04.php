<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8">
    <title><?php echo $__env->yieldContent('title','RESUME'); ?></title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <!--enable mobile device-->
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--fontawesome css-->
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/font-awesome.min.css">
    <link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">
    <!--bootstrap css-->
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/bootstrap.min.css">
    <!--animate css-->
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/animate-wow.css">
    <!--main css-->
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/orbit.css">
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/bootstrap-select.min.css">
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/slick.min.css">
    <!--responsive css-->
    <link rel="stylesheet" href="<?php echo e(asset('front')); ?>/css/responsive.css">
    <!--phone selection-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />
    <link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/js/intlTelInput.min.js"></script>

    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>
    <div>
        <button id="downloadPDF" value="Download as PDF" onclick="window.print()">AAAA</button>
    </div>
    <div class="wrapper mt-lg-5" id="testDiv">
        <div class="sidebar-wrapper">
            <div class="profile-container">
                <img src="<?php echo e(asset('')); ?><?php echo e(Auth::User()->photo_url); ?>" class="profile-picture" />
                <h1 class="name" style="text-transform: uppercase; font-size:150%"><br><?php echo e($user->name); ?> <br><?php echo e($user->surname); ?></h1>
                <h3 class="tagline"><?php echo e($user->current_position); ?></h3>
            </div>
            <!--//profile-container-->

            <div class="contact-container container-block">
                <ul class="list-unstyled contact-list">
                    <li class="email"><i class="fas fa-envelope"></i><a href="mailto: yourname@email.com"> <?php echo e($user->email); ?></a></li>
                    <li class="phone"><i class="fas fa-phone"></i><a href="tel:<?php echo e($user->phone); ?>"> <?php echo e($user->phone); ?></a></li>
                </ul>
            </div>
            <!--//contact-container-->
            <div class="education-container container-block">
                <h2 class="container-block-title">Education</h2>
                <?php $__currentLoopData = $user->educations->sortByDesc('from_time'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $education): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <h4 class="degree"><?php echo e($education->education_level); ?></h4>
                    <h5 class="meta"><?php echo e($education->school); ?></h5>
                    <div class="time"><?php echo e($education->from_time); ?> - <?php echo e($education->to_time); ?></div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
            <!--//education-container-->

            <div class="languages-container container-block">
                <h2 class="container-block-title">Languages</h2>
                <ul class="list-unstyled interests-list">
                    <?php $__currentLoopData = $user->languages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <?php echo e($language->name); ?> <span class="lang-desc"><?php echo e($language->proficiency); ?></span>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </div>
        </div>
        <!--//sidebar-wrapper-->

        <div class="main-wrapper">

            <section class="section summary-section">
                <h2 class="section-title">
                    <span class="material-icons">account_circle</span> ABOUT ME
                </h2>
                <div class="summary">
                    <p><?php echo e($user->about); ?></p>
                </div>
                <!--//summary-->
            </section>
            <!--//section-->

            <section class="section experiences-section">
                <h2 class="section-title"><span class="material-icons">work</span> Experiences</h2>
                <?php $__currentLoopData = $user->experiences->sortByDesc('from_time'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $experience): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title"><?php echo e($experience->position); ?></h3>
                            <div class="time"><?php echo e($experience->from_time); ?> - <?php echo e($experience->to_time); ?></div>
                        </div>
                        <!--//upper-row-->
                        <div class="company"><?php echo e($experience->company_name); ?></div>
                    </div>
                    <!--//meta-->
                    <div class="details">
                        <p><?php echo e($experience->description); ?></p>
                    </div>
                    <!--//details-->
                </div>
                <!--//item-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
            <!--//section-->


            <!--//section-->
            <section class="section experiences-section">
                <h2 class="section-title"><span class="material-icons">assignment</span> Courses</h2>
                <?php $__currentLoopData = $user->courses->sortByDesc('from_time'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="item">
                    <div class="meta">
                        <div class="upper-row">
                            <h3 class="job-title"><?php echo e($course->name); ?></h3>
                            <div class="time"><?php echo e($course->from_time); ?> - <?php echo e($course->to_time); ?></div>
                        </div>
                        <!--//upper-row-->
                        <div class="company"><?php echo e($course->provider); ?></div>
                    </div>
                    <!--//meta-->
                    <div class="details">
                        <p><?php echo e($course->description); ?></p>
                    </div>
                    <!--//details-->
                </div>
                <!--//item-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>

            <section class="section projects-section">
                <h2 class="section-title"><span class="material-icons">rocket</span> Skills</h2>
                <?php $__currentLoopData = $user->skills->sortBy('type'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $skill): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <!--//intro-->
                <div class="item">
                    <span class="project-title" style="float: left; width:45%;"><?php echo e($skill->name); ?></span>
                    <span class="material-icons">
                        arrow_forward_ios
                    </span>
                    <span class="project-tagline" style="float:right; width:20%;"> <?php echo e($skill->type); ?> </span>
                </div>
                <!--//item-->
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </section>
        </div>
        <!--//main-body-->
    </div>
    
</body>
<!-- Bootstrap core JavaScript-->
<script src="<?php echo e(asset('back/')); ?>/vendor/jquery/jquery.min.js"></script>
<script src="<?php echo e(asset('back/')); ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

<!-- Core plugin JavaScript-->
<script src="<?php echo e(asset('back/')); ?>/vendor/jquery-easing/jquery.easing.min.js"></script>

<!-- Custom scripts for all pages-->
<script src="<?php echo e(asset('back/')); ?>/js/sb-admin-2.min.js"></script>

<!-- Page level plugins -->
<script src="<?php echo e(asset('back/')); ?>/vendor/chart.js/Chart.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('back/')); ?>/js/demo/chart-area-demo.js"></script>
<script src="<?php echo e(asset('back/')); ?>/js/demo/chart-pie-demo.js"></script>
<script src="<?php echo e(asset('back/')); ?>/vendor/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo e(asset('back/')); ?>/vendor/datatables/dataTables.bootstrap4.min.js"></script>

<!-- Page level custom scripts -->
<script src="<?php echo e(asset('back/')); ?>/js/demo/datatables-demo.js"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/summernote@0.8.18/dist/summernote-bs4.min.js"></script>
<script>
    $(document).ready(function() {
        $('#summernote').summernote({
            'height': 400
        });
    });
</script>
<script>

    function PrintElem(elem)
{
      Popup($('<div/>').append($(elem).clone()).html());
}

function Popup(data) 
{
    var mywindow = window.open();
    mywindow.document.write('<html><head><title>my div</title>');
    mywindow.document.write('<link rel="stylesheet" href="public/front/css/orbit.css">');
    mywindow.document.write('<link rel="stylesheet" href="public/front/css/bootstrap.min.css">');
    mywindow.document.write('<link rel="stylesheet" href="public/front/css/animate-wow.css">');
    mywindow.document.write('<link rel="stylesheet" href="public/front/css/style.css">');
    mywindow.document.write('<link rel="stylesheet" href="public/front/css/bootstrap-select.min.css">');
    mywindow.document.write('<link rel="stylesheet" href="public/front/css/slick.min.css">');
    mywindow.document.write('<link rel="stylesheet" href="//use.fontawesome.com/releases/v5.0.7/css/all.css">');
    mywindow.document.write('<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/17.0.8/css/intlTelInput.css" />');
    mywindow.document.write('<link rel="stylesheet" href="https://fonts.googleapis.com/icon?family=Material+Icons">');
    mywindow.document.write('</head><body >');
    mywindow.document.write(data);
    mywindow.document.write('</body></html>');
    
  
    mywindow.print();
  //  mywindow.close();
  
    return true;
}
//PrintElem(testDiv);


</script>

<?php echo toastr_js(); ?>
<?php echo app('toastr')->render(); ?>
<?php echo $__env->yieldContent('js'); ?>

</html>
<?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/users/test_pdf.blade.php ENDPATH**/ ?>