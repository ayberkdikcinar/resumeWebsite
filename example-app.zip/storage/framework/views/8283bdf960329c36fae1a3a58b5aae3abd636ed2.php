<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
    <?php if(count($errors)>0): ?>
    <div class="alert alert-danger">
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php echo e($error); ?>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    <?php endif; ?>
    <form action="<?php echo e(route('resume.documents.post','english-test')); ?>" method="POST" enctype="multipart/form-data">
        <?php echo csrf_field(); ?>
        <input id="file-input" type="file" name="file" accept="image/*,.pdf" />
        <input type="submit" name="submit" class="btn btn-warning" value="Set About" />
    </form>
    
</body>
</html><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/resume/documents.blade.php ENDPATH**/ ?>