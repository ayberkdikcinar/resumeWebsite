
<?php $__env->startSection('title','List Users'); ?>
<?php $__env->startSection('content'); ?>

 <!-- DataTales Example -->
 <div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary"><strong><?php echo e($users->count()); ?> </strong>
            <?php if($checked == "on"): ?>
                admins have been found!
            <?php else: ?>
                customers have been found!
            <?php endif; ?>
            </h6>
    </div>
    <div class="card-body">
        
        <div class="checkbox-usertype" style="text-align: center; vertical-align: middle;">
            <form name="myForm" action="" method="get">
            <label for=""><input type="checkbox" id="checkboxid" name="checkbox_val" style="margin: 5px; width:20px; heigth:20px;" <?php if($checked=="on"): ?> ? checked : <?php endif; ?>>Show Only Admins</label>
            </form>
        </div>
       
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Photo</th>
                        <th>Username</th>
                        <th>Name</th>
                        <th>Surname</th>
                        <th>Email</th>
                        <th>Phone</th>
                        <th>Current Position</th>  
                        <th>Operations</th>
                    </tr>
                </thead>
              
                <tbody>
                    
                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    
                    <tr>
                        <td style="text-align: center; vertical-align: middle;">
                            <img src="<?php echo e(asset('')); ?><?php echo e($user->photo_url); ?>" width="90">
                        </td>
                        <td><?php echo e($user->username); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->surname); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->phone); ?></td>
                        <td><?php echo e($user->current_position); ?></td>
                        <td style="text-align: center; vertical-align: middle;">
                            <a href="<?php echo e(route('admin.user.show', $user->id)); ?>" title="Show Details" class="btn btn-sm btn-success"><i class="fa fa-eye"></i></a>
                            <a href="<?php echo e(route('admin.user.edit', $user->id)); ?>" title="Update" class="btn btn-sm btn-primary"><i class="fa fa-pen"></i></a>
                            <a href="<?php echo e(route('admin.mailView',$user->id)); ?>" title="Send Email" class="btn btn-sm btn-warning"><i class="fa fa-envelope-open" style="color: white"></i></a>
                            <a href="#!" data-toggle="modal" data-url="<?php echo e(route('admin.user.destroy', $user->id)); ?>" 
                                data-target="#deleteUserModal" title="Delete" class="btn btn-sm btn-danger delete"><i class="fa fa-times delete"></i></a>
                        </td>
                    </tr> 
                   
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                   
              
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
    var form = document.getElementsByName("myForm")[0];
    var checkBox = document.getElementById("checkboxid");

    checkBox.onchange = function(){
    if(this.checked){
        form.action =  `<?php echo e(route('admin.user.index')); ?>`;   
    }else{
        form.action = `<?php echo e(route('admin.user.index')); ?>`;
    }
    form.submit();
    };
    
</script>
<script> 
    $(document).on('click', '.delete', function(e) {
        e.preventDefault();
        const id = $(this).data('url');
        $('#deleteFormClient').attr('action', id);
    })
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/users/listUser.blade.php ENDPATH**/ ?>