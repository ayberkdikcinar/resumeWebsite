
<?php $__env->startSection('title'); ?>
<?php echo $contactUs->title; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="does-box">
   <p style="text-align: center; font-size: xx-large"><?php echo $contactUs->title; ?></p>
   <div class="container">
      <div class="panel-body">
         <div style="margin-bottom:40px;">
            <?php echo $contactUs->content; ?>

         </div>
         <div>
            <img class="img-responsive" src="<?php echo e(asset('')); ?><?php echo e($contactUs->image_url); ?>"/>
         </div>
      
      </div> 
   </div>  
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/front/contact_us.blade.php ENDPATH**/ ?>