
<?php $__env->startSection('title'); ?>
<?php echo e($homepage->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="page-content-product">
   <div class="main-product" style="background-image: url('<?php echo e(asset("")); ?><?php echo e($homepage->banner_image_url); ?>');">
      <!-- bu fotoğrafta backten çekilecek -->
      <div class="container">
         <div class="row clearfix">
            <div class="find-box">
               <h1><?php echo $homepage->bannerTitle; ?></h1>
               <h4><?php echo $homepage->bannerContent; ?></h4>
            </div>
         </div>
      </div>
   </div>
   <div class="cat-main-box">
      <div class="container">
         <div class="row panel-row">
            <div class="col-md-4 col-sm-6 wow fadeIn" data-wow-delay="0.0s">
               <div class="panel panel-default">
                  <div class="panel-body">
                     <h4><?php echo $homepage->card_one_title; ?></h4>
                     <p><?php echo $homepage->card_one_content; ?></p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 wow fadeIn" data-wow-delay="0.2s">
               <div class="panel panel-default">
                  <div class="panel-body">
                     <h4><?php echo $homepage->card_two_title; ?></h4>
                     <p><?php echo $homepage->card_two_content; ?></p>
                  </div>
               </div>
            </div>
            <div class="col-md-4 col-sm-6 wow fadeIn hidden-sm" data-wow-delay="0.4s">
               <div class="panel panel-default">
                  <div class="panel-body">
                     <h4><?php echo $homepage->card_three_title; ?></h4>
                     <p><?php echo $homepage->card_three_content; ?></p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>

   <div class="products_exciting_box">
      <center>
         <h3>{<?php echo $homepage->top_body_title; ?>}</h3>
      </center>
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-sm-6 wow fadeIn" data-wow-delay="0.2s">
               <div class="exciting_box f_pd">
                  <p>{<?php echo $homepage->top_body_left_content; ?>}</p>
               </div>
            </div>
            <div class="col-md-6 col-sm-6 wow fadeIn" data-wow-delay="0.4s">
               <div class="exciting_box l_pd">
                  <p>{<?php echo $homepage->top_body_right_content; ?>}</p>
               </div>
            </div>
         </div>
      </div>
   </div>

   <div class="products_exciting_box">
      <div class="container">
         <div class="row">
            <div class="col-md-6 col-sm-6 wow fadeIn" data-wow-delay="0.2s">
               <div class="exciting_box f_pd">
                  <h3>{<?php echo $homepage->bottom_body_title; ?>}</h3>
               </div>
            </div>
            <div class="col-md-6 col-sm-6 wow fadeIn" data-wow-delay="0.4s">
               <div class="exciting_box l_pd">
                  <p>{<?php echo $homepage->bottom_body_content; ?>}</p>
               </div>
            </div>
         </div>
      </div>
   </div>
</div>
<?php echo $homepage->content; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/front/index.blade.php ENDPATH**/ ?>