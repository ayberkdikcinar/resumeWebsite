
<?php $__env->startSection('title'); ?>
<?php echo e($loginpage->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
  
    <div class="card-body">
        <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>    
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.pagesUpdatePost','loginpage')); ?>" method="POST" enctype="multipart/form-data">
           
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Title <label style="color: red">*</label> </label>
                <input type="text" name="title" class="form-control" value="<?php echo e($loginpage->title); ?>" required>
            </div>
            <label>Image</label>
            <div class="form-group">
                <div class="image-upload">
                    <label for="file-input">
                      <img src="<?php echo e(asset('')); ?><?php echo e($loginpage->image_url); ?>" width="250" id="uploadPreview"/>
                    </label>
                    <input id="uploadImage" type="file" name="image" accept="image/*" onchange="PreviewImage();"/>
                  </div>
            </div>
            <div class="form-group">
                <button type="submit" name="submit" class="btn-block btn btn-primary">Update</button>
            </div>
        </form>  
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script type="text/javascript">

    function PreviewImage() {
        var oFReader = new FileReader();
        oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

        oFReader.onload = function (oFREvent) {
            document.getElementById("uploadPreview").src = oFREvent.target.result;
        };
    };

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/pages/login_update.blade.php ENDPATH**/ ?>