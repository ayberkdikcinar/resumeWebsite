
<?php $__env->startSection('title'); ?>
<?php echo e($termsOfUse->title); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="card shadow mb-4">
  
    <div class="card-body">
        <?php if(count($errors)>0): ?>
        <div class="alert alert-danger">
            <ul>
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <li><?php echo e($error); ?></li>           
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>    
        </div>
        <?php endif; ?>
        <form action="<?php echo e(route('admin.pagesUpdatePost','terms-of-use')); ?>" method="POST">
           
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Title <label style="color: red">*</label> </label>
                <input type="text" name="title" class="form-control" value="<?php echo e($termsOfUse->title); ?>" required>
            </div>
          
            <label>Content</label>
            <textarea name="content" id="summernote"><?php echo $termsOfUse->content; ?></textarea>
            <div class="form-group">
                <button type="submit" name="submit" class="btn-block btn btn-primary">Update</button>
            </div>

        </form>  
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminPanel.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/adminPanel/pages/terms_of_use_update.blade.php ENDPATH**/ ?>