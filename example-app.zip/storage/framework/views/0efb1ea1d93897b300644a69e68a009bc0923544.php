
<?php $__env->startSection('title'); ?>
<?php echo $howItWorks->title; ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="does-box">
      <p style="text-align: center; font-size: xx-large"><?php echo $howItWorks->title; ?></p>
      <div class="container">
         <div class="panel-body">
            <?php echo $howItWorks->content; ?>

         </div>  
      </div>
</div>    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/front/how_it_works.blade.php ENDPATH**/ ?>