
<?php $__env->startSection('title'); ?>
Terms Of Use
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="terms-conditions">
 
    <div class="container">
       <div class="row">
        <?php echo $privacyPolicies->content; ?>

       </div>
    </div>
 </div>   
<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/front/privacy_policies.blade.php ENDPATH**/ ?>