
<?php $__env->startSection('title'); ?>
Login
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    <div class="container">
      <div class="row">
        <div class="col-md-6">
          <img src="<?php echo e(asset('')); ?><?php echo e($loginpage->image_url); ?>" alt="Image" class="img-fluid">
        </div>
        <div class="col-md-6 contents">
          <div class="row justify-content-center">
            <div class="col-md-8">
              <?php if(count($errors)>0): ?>
              <div class="alert alert-danger">
                      <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <?php echo e($error); ?>           
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
              </div>
              <?php endif; ?>
            <form action="<?php echo e(route('login.post')); ?>" method="post">
              <?php echo csrf_field(); ?>
              <div class="form-group first">
                <label for="username">Username</label>
                <input type="text" class="form-control" id="username" name="username">

              </div>
              <div class="form-group last mb-4">
                <label for="password">Password</label>
                <input type="password" class="input-lg form-control" name="password" id="password"> 
              </div>

              <input type="submit" value="Log In" class="btn btn-block btn-primary">
            </form>
            </div>
          </div>
          
        </div>
        
      </div>
    </div>
  </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('front.layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\ayber\Desktop\example-app\resources\views/front/login.blade.php ENDPATH**/ ?>